# Member 3 Refactoring Notes — Codebase A

## Changes implemented
1. Extracted repeated SQL for counting paid tickets into `get_paid_ticket_count(db, event_id)`.
   The event detail and booking routes now reuse this helper.
2. Extracted successful payment confirmation and capacity re-check into `finalize_successful_payment(db, booking)`.
3. Extracted failed simulated payment recording into `finalize_failed_payment(db, booking_id)`.
4. Simplified the `/payment/<booking_id>` route so it coordinates request handling and user feedback while helper functions perform the payment state updates.

## Validation
- Python syntax compilation of `codebase_A/app.py`: PASSED.
- Flask runtime and browser-based functional/regression tests: NOT RUN in the analysis environment because Flask is not installed there. Run `pip install -r requirements.txt` and perform the test cases in the report before claiming functional test pass results.

## Important limitation
This refactoring extracts repeated logic and reduces the length/responsibilities of the payment route. It does not fully split the monolithic `app.py` into Blueprints/modules, and it does not introduce transaction locking for concurrent payments. These remain possible future improvements.
